// modifikasi JavaScript disini
// 
console.log('instalasi berhasil');
// mulai modifikasi....
// *****************************************
function nav2Function() {
    var x = document.getElementById("nav2");
    if (x.className === "nav2") {
        x.className += " responsive2";
    } else {
        x.className = "nav2";
    }
};

/*
modifikasi JavaScript sesuai keinginan mu
*animasi
*durasi
*filter
*efek
*/